import yaml

data = {
    'jobs':[
        {
        'job_id': '1',
        'job_name': "transform csv",
        'tasks': [
            {
            'id': 1,
            'runner': 'readers.csv_reader.CsvReader',
            'params':r'file_path=C:\work\python_batch\batch\test\test1.csv;'
            },
            {
            'id': 2,
            'module': 'csv_writer',
            'params':r'file_path=C:\work\python_batch\batch\test\test1.csv;'
            }
        ]
        },
        {
        'job_id': '2',
        'job_name': "dummy",
        'tasks': [
            {
            'id': 1,
            'runner': 'readers.csv_reader.CsvReader',
            'params':r'file_path=C:\work\python_batch\batch\test\test1.csv;'
            },
            {
            'id': 2,
            'module': 'csv_writer',
            'params':r'file_path=C:\work\python_batch\batch\test\test1.csv;'
            }
        ]
        }

    ],

}

with open('config.yaml', 'w') as file:
    yaml.dump(data, file)