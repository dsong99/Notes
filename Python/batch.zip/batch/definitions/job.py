import os, sys

class Job(object):
    def __init__(self,job_desc:dict):
        self.job_desc = job_desc
        self.job_id = job_desc['job_id']
        self.job_name = job_desc['job_name']
        self.tasks = job_desc['tasks']
        self.status = 'None'
        self.job_desc.update({'status':self.status})

    def set_job_param(self, params):
        self.job_param = params

    def get_job_state(self):
        self.job_desc['status'] = self.status
        return self.job_desc

    def run(self):
        pass

    def __str__(self):
        return str(self.job_desc)