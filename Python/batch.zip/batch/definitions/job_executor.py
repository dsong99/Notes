
import utils
import logging
logger = logging.getLogger(__name__)

import threading
from concurrent.futures import ProcessPoolExecutor
from definitions.job import Job

class JobExecutor():

    lock = threading.Lock()
    executor:ProcessPoolExecutor =None

    def __init__(self):
        self.__init_executor()
    def __init_executor(self):
        if JobExecutor.executor is None:
            with JobExecutor.lock:
                if JobExecutor.executor is None:
                    JobExecutor.executor = ProcessPoolExecutor(4)

    def run_job(self, job_id):
        from definitions.job_factory import JobInitilizer
        jobs = JobInitilizer.get_jobs()
        job = [job for job in jobs if job.job_id == str(job_id)]
        JobExecutor.executor.submit(job.run)
