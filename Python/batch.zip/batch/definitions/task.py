import os, sys
import logging
import traceback
from abc import ABC, abstractmethod
logger = logging.getLogger(__name__)


class Task(ABC):

    def __init__(self):
        self.job_id = None

    @abstractmethod
    def run(self):
        pass

    def set_jobID(self, job_id):
        self.job_id = job_id

    def get_job_session(self):
        job_desc = None
        try:
            job_desc = os.environ['batch'][self.job_id]
        except Exception as ex:
            logger.error(ex)
            traceback.print_exc()
        finally:
            return job_desc
