requires only create tasks, and add tasks in configuration

fastAPI
    start -> initJobs from configurations or DB
    receives a request -> construct a job -> submit to job executor
