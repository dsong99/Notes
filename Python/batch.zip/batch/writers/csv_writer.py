
from definitions.task import Task
import pandas as pd

class CsvWriter(Task):
    def write(self):
        pass
