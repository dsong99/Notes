
from definitions.task import Task
import pandas as pd
import logging
logger = logging.getLogger(__name__)

class CsvReader(Task):
    def run(self):
        logger.info('reading ...')
        #return pd.read_csv()